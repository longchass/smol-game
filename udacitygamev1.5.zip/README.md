# a little fun cross the road game
use arrow keys to move
↑ -move up
↓ -move down
← -move to the left
→ -move to the right
update v1.1 implemented scores system
unzip and run the index.html file the game will automatically start
have fun
